/*
 * Array to be accessed by all of the pages to store user values 
 */
package groupproject;

import java.util.ArrayList;

/**
 *
 * @author Rhiannon Markegard
 * @ver v3 12/10/18
 */
public class fieldArray {

    public static ArrayList<Fields> var = new ArrayList<Fields>();
    public static String toppings = "";

    //method to display stuff from array
    public static String displayChoices() {
        String commaToppings = "";
        for (Fields item : var) {
            toppings = toppings + item.field + "\r\n";
            commaToppings = commaToppings + item.field + ",";   
        }
        commaToppings = commaToppings.substring(0, commaToppings.length()-1);
        Values.pizzaToppings = commaToppings;
        return toppings;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author rhian
 */
public class CSVWriter {
    File outFile = new File("output.txt");
    String userChoice;
    public void write(String choice) throws FileNotFoundException, IOException {
        
        FileWriter fWriter = new FileWriter(outFile);
        PrintWriter pWriter = new PrintWriter(fWriter);
        userChoice = choice;
        pWriter.println(userChoice);
        
        pWriter.close();
        
    }
    
    public void read() throws FileNotFoundException{
        //reads output file
        Scanner sc2 = new Scanner(outFile);
        //prints out file line
        while (sc2.hasNextLine()) {
            String line2 = sc2.nextLine();
            System.out.println(line2);
        }
        sc2.close();
    }
}

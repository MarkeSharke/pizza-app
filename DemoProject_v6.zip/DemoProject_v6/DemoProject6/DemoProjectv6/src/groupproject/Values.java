/*
 * Stores all the values recorded throughout the program
 */
package groupproject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 *
 * @author Rhiannon Markegard
 * @ver v3 12/11/18
 */
public class Values {

    public static String pizzaSize;
    public static String pizzaCrust;
    public static String pizzaSauce;
    public static String pizzaToppings;
    public static String specReq;
    public static String drinkChoice;
    public static String bStickChoice;
    public static String bStickSauceChoice;
    public static String name;
    public static String address;
    public static String phoneNum;
    public static String deliveryInstruc;
    public static String creditCardNum;
    public static String tip;
   
    public static void createCSV() throws FileNotFoundException {
        File csv = new File("order.csv");
        if (!csv.exists()) {
            System.out.println("Printed Headers");
            PrintWriter pw = new PrintWriter(csv);
            StringBuilder sb = new StringBuilder();
            sb.append("Name");
            sb.append(',');
            sb.append("Address");
            sb.append(',');
            sb.append("Phone Number");
            sb.append(',');
            sb.append("Credit Card #");
            sb.append(',');
            sb.append("Pizza Size");
            sb.append(',');
            sb.append("Pizza Crust");
            sb.append(',');
            sb.append("Pizza Sauce");
            sb.append(',');
            sb.append("Drink Choice");
            sb.append(',');
            sb.append("Bread Sticks");
            sb.append(',');
            sb.append("Bread Stick Sauce");
            sb.append(',');
            sb.append("Special Requests");
            sb.append(',');
            sb.append("Delivery Instructions");
            sb.append(',');
            sb.append("Pizza Toppings");
            
            pw.write(sb.toString());
            pw.close();
        }
        else{
            System.out.println("no headers");
        }
    }

    public static void writeToCSV() {
        try {
            File csv = new File("order.csv");
            if (csv.exists()) {
                FileWriter fw = new FileWriter("order.csv", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter pw = new PrintWriter(bw);
                StringBuilder sb = new StringBuilder();
                
                sb.append('\n');
                sb.append(name);
                sb.append(',');
                sb.append(address);
                sb.append(',');
                sb.append(phoneNum);
                sb.append(',');
                sb.append(creditCardNum);
                sb.append(',');
                sb.append(pizzaSize);
                sb.append(',');
                sb.append(pizzaCrust);
                sb.append(',');
                sb.append(pizzaSauce);
                sb.append(',');
                sb.append(drinkChoice);
                sb.append(',');
                sb.append(bStickChoice);
                sb.append(',');
                sb.append(bStickSauceChoice);
                sb.append(',');
                sb.append(specReq);
                sb.append(',');
                sb.append(deliveryInstruc);
                sb.append(',');
                sb.append(pizzaToppings); 
                
                pw.append(sb.toString());
                pw.close();
                bw.close();
                fw.close();
                
                name = "";
                address = "";
                phoneNum = "";
                creditCardNum = "";
                pizzaSize = "";
                pizzaCrust = "";
                pizzaSauce = "";
                drinkChoice = "";
                bStickChoice = "";
                bStickSauceChoice = "";
                specReq = "";
                deliveryInstruc = "";
                pizzaToppings = "";   
            }
        } 
        catch (Exception ex) {
            System.out.println("Error");
        }
    }

}

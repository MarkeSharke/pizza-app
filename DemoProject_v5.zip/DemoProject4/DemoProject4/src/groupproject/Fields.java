/*
 * Used for storing the values that are selected by the user
 * so that they can theorically be displayed back later
 * that is if I can figure out how to implement my idea
 */
package groupproject;

/**
 *
 * @author Rhiannon Markegard
 * @ver v1 12/6/18
 */
public class Fields {
    public boolean data = false;
    public String field = "";
}

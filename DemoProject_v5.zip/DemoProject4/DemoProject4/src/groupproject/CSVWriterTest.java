/*
 * Write and Read a CSV file
 */
package groupproject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
/**
 *
 * @author Rhiannon Markegard
 * @ver v1 12/4/18
 */
public class CSVWriterTest {
    public static void main(String[]args) throws FileNotFoundException{
        //Write to CSV file 'test.csv'
        PrintWriter pw = new PrintWriter(new File("test.csv"));
        StringBuilder sb = new StringBuilder();
        sb.append("id");
        sb.append(',');
        sb.append("Name");
        sb.append('\n');

        sb.append("1");
        sb.append(',');
        sb.append("YEET");
        sb.append('\n');
        
        

        pw.write(sb.toString());
        pw.close();
        System.out.println("done!");
        
        String csvFile = "test.csv";
        String line = "";
        String cvsSplitBy = ",";
        // Array for each line of the file being read
        String[] stuffFromFile; 
        //Read through CSV file w/ Buffered reader
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {

                // use comma as separator
                stuffFromFile = line.split(cvsSplitBy);
                //iterate through csv file and print elements of array
                for(int i = 0; i<stuffFromFile.length; i++){
                    System.out.println(stuffFromFile[i]);
                }
            }
            br.close();
        } 
        catch (IOException ex) {
           System.out.println("Error reading file '" + csvFile + "' -- " + ex.toString());
        }
    }
}
